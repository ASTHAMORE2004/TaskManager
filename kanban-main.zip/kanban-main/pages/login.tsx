import Auth from "../components/Auth/Auth";

type Props = {};

const Login = (props: Props) => {
  return <Auth action="login" />;
};

export default Login;
