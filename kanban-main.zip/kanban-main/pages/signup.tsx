import Auth from "../components/Auth/Auth";

type Props = {};

const Signup = (props: Props) => {
  return <Auth action="signup" />;
};

export default Signup;
